# Quy ước làm việc của nhóm

## Vòng lặp mỗi thẻ Trello

```bash
git switch main
git pull                                  # lấy code mới nhất
git switch -c siem/hec-alert-thi-giac     # tạo nhánh cho thẻ đang làm
# ... sửa code ...
git status                                # xem đã sửa gì
git add siem/splunk/inputs.conf           # chọn file đưa vào commit
git commit -m "siem: thêm cấu hình HEC nhận alert thị giác"
git push -u origin siem/hec-alert-thi-giac
```

Sau đó lên GitHub bấm **Compare & pull request**, dán link thẻ Trello vào mô tả,
chọn P1 làm reviewer, chuyển thẻ sang cột **Chờ review**.

## Đặt tên nhánh

`<thư-mục>/<mô-tả-ngắn-không-dấu>`, ví dụ `vision/bang-f-suy-giam`,
`dataset/manifest-composite`, `demo/kich-ban-demo-b`.

## Commit message

`<thư-mục>: <làm gì>` — viết ở thì hiện tại, một việc mỗi commit.
Ví dụ: `vision: sửa layer Grad-CAM sang model[22]`.

## Tuyệt đối không commit

- Dataset, ảnh, video, file `.evtx` → để trên Google Drive, repo chỉ giữ script và `manifest.csv`
- Trọng số model (`*.pt`, `*.onnx`, `*.engine`) và thư mục `runs/`
- File `.env`, token Splunk HEC, API key AbuseIPDB, token bot Telegram, mật khẩu

Lỡ commit token: báo P1 và **thu hồi token ngay**. Xoá file bằng commit mới
không đủ, lịch sử Git vẫn giữ bản cũ.

## Khi nào được merge

- Pull Request có link thẻ Trello và mô tả đã kiểm thử thế nào
- P1 (hoặc người được P1 chỉ định) đã duyệt
- Code chạy được, không phá phần của nhóm khác
