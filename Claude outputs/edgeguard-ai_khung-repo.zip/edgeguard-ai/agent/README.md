# agent/ — P1 (làm sau thị giác)
AI Agent nhận ticket (D): làm giàu → RAG (ATT&CK + ATLAS) → Reflection → Deterministic Override → hành động qua người duyệt → audit log.
