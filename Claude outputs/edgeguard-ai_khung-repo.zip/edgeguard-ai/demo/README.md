# demo/ — P4, P5
Kịch bản demo theo thứ tự bắt buộc A → B → C (A: chỉ thị giác, B: chỉ mã độc + ca âm tính, C: liên nhánh).
Mỗi kịch bản ghi từng giây: ai làm gì, alert nào nổ, màn hình nào chiếu. Video quay dự phòng để trên Drive.
