# prefilter/ — P1 (làm sau thị giác)
ML Pre-filter: OR-gate `is_always_analyze_type OR proba > THRESHOLD`, bake-off Random Forest vs LightGBM, chạy shadow mode trước.
