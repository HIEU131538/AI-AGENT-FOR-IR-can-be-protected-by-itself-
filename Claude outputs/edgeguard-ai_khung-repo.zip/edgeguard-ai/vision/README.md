# vision/ — P1
Nhánh thị giác: YOLO11s → Grad-CAM (model[22]) → chỉ số C/D/E → Logistic Regression → suspicion_score → Jedi / LGS → alert (A) ký HMAC.
Chuyển code từ repo cũ `edgeguard-vision` vào đây. Trọng số `.pt` không commit.
