# docs/ — cả nhóm
- `adr/`: mỗi quyết định kiến trúc một file (ADR-01, ADR-02, ...)
- `hop-nhom/`: biên bản họp tuần (ngày, ai dự, xong gì, bị chặn gì)
- báo cáo NCKH, hình vẽ kiến trúc
