# EdgeGuard-AI

Đề tài NCKH sinh viên, Học viện Kỹ thuật Mật mã (2026–2027).
Hệ thống phát hiện và phản ứng sự cố tự động cho mạng camera AI ở biên:
nhánh **thị giác** phát hiện adversarial patch trên YOLO, nhánh **hệ điều hành**
phát hiện fileless malware trên Gateway qua Sysmon → Splunk, cả hai đổ về một
**AI Agent** (LangGraph + Llama 3.1 8B chạy cục bộ qua Ollama).

## Thư mục và người phụ trách

| Thư mục | Nội dung | Phụ trách |
|---|---|---|
| `vision/` | YOLO11s, Grad-CAM, chỉ số C/D/E, Jedi, LGS, benchmark | P1 |
| `siem/` | Cấu hình Sysmon, Splunk (Forwarder, HEC, correlation search) | P2, P3 |
| `dataset/` | Script thu thập, làm sạch, manifest (dữ liệu thật để trên Drive) | P4, P5 |
| `demo/` | Kịch bản demo A / B / C, ghi chú quay video | P4, P5 |
| `prefilter/` | ML Pre-filter (Random Forest / LightGBM) | P1 (sau) |
| `agent/` | AI Agent dạng ticket | P1 (sau) |
| `docs/` | Báo cáo, quyết định kiến trúc (ADR), biên bản họp | cả nhóm |

## Quy tắc làm việc

Đọc `CONTRIBUTING.md` trước khi commit lần đầu. Tóm tắt: không push thẳng `main`,
mỗi thẻ Trello là một nhánh, gộp code qua Pull Request, không bao giờ commit
dữ liệu, trọng số model hay token/mật khẩu.

- Bảng tiến độ Trello: <dán link board vào đây>
- Thư mục dữ liệu Google Drive: <dán link vào đây>
