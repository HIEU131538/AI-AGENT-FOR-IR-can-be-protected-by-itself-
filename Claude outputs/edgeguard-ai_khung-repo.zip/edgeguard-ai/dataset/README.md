# dataset/ — P4, P5
Dữ liệu thật để trên Google Drive (link trong README gốc). Thư mục này chỉ giữ:
- `scripts/`: script tải, làm sạch, chuẩn hoá, tạo ảnh composite
- `manifest.csv`: mỗi dòng một mẫu (tên file, nguồn, nhãn, ghi chú)
