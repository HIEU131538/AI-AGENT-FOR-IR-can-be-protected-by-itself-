# siem/ — P2, P3
- `sysmon/`: file cấu hình Sysmon (XML) dùng trên Gateway Windows Server
- `splunk/`: inputs.conf / props.conf của Universal Forwarder, cấu hình HEC, các correlation search (SPL) sinh alert (B)
Không commit token HEC; dùng `.env`.
