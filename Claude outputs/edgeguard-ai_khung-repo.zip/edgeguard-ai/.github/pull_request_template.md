## Thẻ Trello
<!-- dán link thẻ -->

## Làm gì
<!-- 1–3 dòng -->

## Đã kiểm thử thế nào
<!-- lệnh đã chạy, ảnh chụp, số đo -->

## Checklist
- [ ] Không có dataset, trọng số model, file .env hay token trong PR
- [ ] Chỉ sửa trong thư mục của nhóm mình (nếu sửa chỗ khác đã báo người phụ trách)
- [ ] Đã chuyển thẻ Trello sang "Chờ review"
